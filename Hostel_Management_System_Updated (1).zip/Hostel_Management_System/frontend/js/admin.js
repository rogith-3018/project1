// ===============================
// Admin Dashboard
// ===============================

document.addEventListener("DOMContentLoaded", function () {

    console.log("Admin Dashboard Loaded");

    // Temporary values
    // Actual values will come from MySQL later.

    document.getElementById("hostelCount").textContent = "--";
    document.getElementById("roomCount").textContent = "--";
    document.getElementById("studentCount").textContent = "--";
    document.getElementById("capacity").textContent = "--";

    document.getElementById("feeStatus").textContent = "--";
    document.getElementById("complaintCount").textContent = "--";
    document.getElementById("attendance").textContent = "--";
    document.getElementById("visitorCount").textContent = "--";
});


// ===============================
// Navigation
// ===============================

function openStudents() {
    window.location.href = "students.html";
}

function openRooms() {
    window.location.href = "rooms.html";
}

function openFees() {
    window.location.href = "fees.html";
}

function openAnalytics() {
    window.location.href = "analytics.html";
}


// ===============================
// Notification
// ===============================

function showMessage() {

    alert(
        "Notification system will be connected to the backend later."
    );
}


// ===============================
// AI
// ===============================

function aiComingSoon() {

    alert(
        "AI Prediction module will be connected later."
    );
}


// ===============================
// Logout
// ===============================

function logout() {

    const confirmLogout = confirm(
        "Are you sure you want to logout?"
    );

    if (confirmLogout) {

        // Later we will clear JWT/session here.

        window.location.href = "../login.html";
    }
}