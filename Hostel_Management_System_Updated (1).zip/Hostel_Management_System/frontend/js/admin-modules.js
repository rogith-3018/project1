
const STORE = {
  menus:"hms_menus", meals:"hms_meals", complaints:"hms_complaints",
  visitors:"hms_visitors", notifications:"hms_notifications", settings:"hms_settings"
};
const $ = id => document.getElementById(id);
const read = (key, fallback=[]) => { try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)); } catch(e){ return fallback; } };
const write = (key, value) => localStorage.setItem(key, JSON.stringify(value));
const uid = () => Date.now().toString(36)+Math.random().toString(36).slice(2,7);
const esc = s => String(s ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]));
const today = () => new Date().toISOString().slice(0,10);
const fmtDate = d => d ? new Date(d+"T00:00:00").toLocaleDateString() : "-";

function logout(){ if(confirm("Are you sure you want to logout?")) location.href="../login.html"; }
function setActiveAdminNav(key){
  document.querySelectorAll(".menu a").forEach(a=>{ if(a.getAttribute("href")===key+".html") a.classList.add("active"); });
}

function seedData(){
  if(!localStorage.getItem(STORE.menus)) write(STORE.menus,[
    {id:uid(),date:today(),meal:"Breakfast",items:"Idli, Sambar, Chutney",price:40},
    {id:uid(),date:today(),meal:"Lunch",items:"Rice, Dal, Vegetable Curry, Curd",price:60},
    {id:uid(),date:today(),meal:"Dinner",items:"Chapati, Paneer Curry, Rice",price:55}
  ]);
  if(!localStorage.getItem(STORE.complaints)) write(STORE.complaints,[
    {id:uid(),student:"Arun Kumar",subject:"Water issue",text:"Water supply is low on the second floor.",date:today(),status:"Pending",reply:""},
    {id:uid(),student:"Priya S",subject:"Room maintenance",text:"Please check the room fan.",date:today(),status:"In Progress",reply:"Maintenance team notified."}
  ]);
  if(!localStorage.getItem(STORE.visitors)) write(STORE.visitors,[]);
  if(!localStorage.getItem(STORE.notifications)) write(STORE.notifications,[]);
  if(!localStorage.getItem(STORE.meals)) write(STORE.meals,[]);
  if(!localStorage.getItem(STORE.settings)) write(STORE.settings,{hostelName:"Hostel Management System",academicYear:"2026-27",warden:"",wardenPhone:"",capacity:100,hostelFee:5000,messFee:3000,email:""});
}

function resetMenuForm(){ $("menuForm")?.reset(); $("menuId").value=""; $("menuDate").value=today(); $("menuPrice").value=50; }
function renderMenus(){
  const rows=read(STORE.menus), q=($("menuSearch")?.value||"").toLowerCase();
  const filtered=rows.filter(x=>[x.date,x.meal,x.items].join(" ").toLowerCase().includes(q)).sort((a,b)=>b.date.localeCompare(a.date));
  $("menuCount") && ($("menuCount").textContent=rows.filter(x=>x.date===today()).length);
  $("menuTable").innerHTML=filtered.length?filtered.map(x=>`<tr><td>${fmtDate(x.date)}</td><td>${esc(x.meal)}</td><td>${esc(x.items)}</td><td>₹${Number(x.price||0).toFixed(0)}</td><td class="actions"><button onclick="editMenu('${x.id}')">Edit</button><button class="btn danger" onclick="deleteMenu('${x.id}')">Delete</button></td></tr>`).join(""):`<tr><td colspan="5" class="empty">No menu records found.</td></tr>`;
}
function editMenu(id){const x=read(STORE.menus).find(v=>v.id===id); if(!x)return; $("menuId").value=x.id;$("menuDate").value=x.date;$("mealType").value=x.meal;$("menuItems").value=x.items;$("menuPrice").value=x.price;scrollTo(0,0);}
function deleteMenu(id){if(!confirm("Delete this menu record?"))return;write(STORE.menus,read(STORE.menus).filter(x=>x.id!==id));renderMenus();}
function renderMeals(){
 const rows=read(STORE.meals).sort((a,b)=>b.date.localeCompare(a.date));
 const served=rows.reduce((s,x)=>s+Number(x.count||0),0); $("mealsServed")&&($("mealsServed").textContent=served);
 $("mealTable").innerHTML=rows.length?rows.map(x=>`<tr><td>${fmtDate(x.date)}</td><td>${esc(x.meal)}</td><td>${x.count}</td><td>${esc(x.notes)}</td><td><button class="btn danger" onclick="deleteMeal('${x.id}')">Delete</button></td></tr>`).join(""):`<tr><td colspan="5" class="empty">No attendance records found.</td></tr>`;
}
function deleteMeal(id){write(STORE.meals,read(STORE.meals).filter(x=>x.id!==id));renderMeals();}
function initMess(){
 if(!$("menuForm"))return; seedData(); $("menuDate").value=today();$("mealDate").value=today();
 $("menuForm").onsubmit=e=>{e.preventDefault();let a=read(STORE.menus), id=$("menuId").value;let x={id:id||uid(),date:$("menuDate").value,meal:$("mealType").value,items:$("menuItems").value.trim(),price:Number($("menuPrice").value||0)};let i=a.findIndex(v=>v.id===id);i>=0?a[i]=x:a.push(x);write(STORE.menus,a);resetMenuForm();renderMenus();};
 $("mealForm").onsubmit=e=>{e.preventDefault();let a=read(STORE.meals);a.push({id:uid(),date:$("mealDate").value,meal:$("attendanceMeal").value,count:Number($("mealCount").value||0),notes:$("mealNotes").value.trim()});write(STORE.meals,a);$("mealForm").reset();$("mealDate").value=today();renderMeals();};
 renderMenus();renderMeals();$("messCollection").textContent="₹"+(read(STORE.menus).filter(x=>x.date.slice(0,7)===today().slice(0,7)).reduce((s,x)=>s+Number(x.price||0),0));
 $("messIssues").textContent=read(STORE.complaints).filter(x=>x.status!=="Resolved").length;
}

function renderComplaints(){
 if(!$("complaintTable"))return; seedData();let rows=read(STORE.complaints),q=($("complaintSearch").value||"").toLowerCase(),f=$("complaintFilter").value;
 let filtered=rows.filter(x=>(!f||x.status===f)&&[x.student,x.subject,x.text,x.reply].join(" ").toLowerCase().includes(q));
 $("complaintTotal").textContent=rows.length;$("complaintPending").textContent=rows.filter(x=>x.status==="Pending").length;$("complaintProgress").textContent=rows.filter(x=>x.status==="In Progress").length;$("complaintResolved").textContent=rows.filter(x=>x.status==="Resolved").length;
 $("complaintTable").innerHTML=filtered.length?filtered.map(x=>`<tr><td>${esc(x.student)}</td><td>${esc(x.subject)}</td><td>${esc(x.text)}</td><td>${fmtDate(x.date)}</td><td><span class="badge ${x.status==="Resolved"?"resolved":x.status==="In Progress"?"progress":"pending"}">${esc(x.status)}</span></td><td>${esc(x.reply||"-")}</td><td class="actions"><button onclick="updateComplaint('${x.id}')">Update</button><button class="btn danger" onclick="deleteComplaint('${x.id}')">Delete</button></td></tr>`).join(""):`<tr><td colspan="7" class="empty">No complaints found.</td></tr>`;
}
function updateComplaint(id){let a=read(STORE.complaints),x=a.find(v=>v.id===id);if(!x)return;let status=prompt("Status: Pending / In Progress / Resolved",x.status);if(status===null)return;status=status.trim();if(!["Pending","In Progress","Resolved"].includes(status)){alert("Please enter Pending, In Progress or Resolved.");return;}let reply=prompt("Admin reply (optional)",x.reply||"");x.status=status;x.reply=reply===null?x.reply:reply.trim();write(STORE.complaints,a);renderComplaints();}
function deleteComplaint(id){if(confirm("Delete this complaint?")){write(STORE.complaints,read(STORE.complaints).filter(x=>x.id!==id));renderComplaints();}}

function resetVisitorForm(){ $("visitorForm")?.reset(); $("visitorId").value=""; $("visitorDate").value=today(); }
function renderVisitors(){
 if(!$("visitorTable"))return;let rows=read(STORE.visitors),q=($("visitorSearch").value||"").toLowerCase();
 let filtered=rows.filter(x=>[x.name,x.student,x.phone,x.purpose,x.date].join(" ").toLowerCase().includes(q)).sort((a,b)=>b.date.localeCompare(a.date));
 $("visitorTotal").textContent=rows.length;$("visitorInside").textContent=rows.filter(x=>!x.out).length;$("visitorToday").textContent=rows.filter(x=>x.date===today()).length;$("visitorRegistered").textContent=new Set(rows.map(x=>x.name.toLowerCase())).size;
 $("visitorTable").innerHTML=filtered.length?filtered.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.student)}</td><td>${esc(x.phone)}</td><td>${esc(x.purpose)}</td><td>${fmtDate(x.date)}</td><td>${esc(x.in)}</td><td>${esc(x.out||"-")}</td><td class="actions"><button onclick="editVisitor('${x.id}')">Edit</button><button class="btn danger" onclick="deleteVisitor('${x.id}')">Delete</button>${!x.out?`<button class="btn success" onclick="markExit('${x.id}')">Mark Exit</button>`:""}</td></tr>`).join(""):`<tr><td colspan="8" class="empty">No visitor records found.</td></tr>`;
}
function editVisitor(id){let x=read(STORE.visitors).find(v=>v.id===id);if(!x)return;$("visitorId").value=x.id;$("visitorName").value=x.name;$("visitorStudent").value=x.student;$("visitorPhone").value=x.phone;$("visitorPurpose").value=x.purpose;$("visitorDate").value=x.date;$("visitorIn").value=x.in;$("visitorOut").value=x.out||"";scrollTo(0,0);}
function deleteVisitor(id){if(confirm("Delete this visitor record?")){write(STORE.visitors,read(STORE.visitors).filter(x=>x.id!==id));renderVisitors();}}
function markExit(id){let a=read(STORE.visitors),x=a.find(v=>v.id===id);if(x){x.out=new Date().toTimeString().slice(0,5);write(STORE.visitors,a);renderVisitors();}}
function initVisitors(){if(!$("visitorForm"))return; $("visitorDate").value=today();$("visitorForm").onsubmit=e=>{e.preventDefault();let a=read(STORE.visitors),id=$("visitorId").value,x={id:id||uid(),name:$("visitorName").value.trim(),student:$("visitorStudent").value.trim(),phone:$("visitorPhone").value.trim(),purpose:$("visitorPurpose").value.trim(),date:$("visitorDate").value,in:$("visitorIn").value,out:$("visitorOut").value};let i=a.findIndex(v=>v.id===id);i>=0?a[i]=x:a.push(x);write(STORE.visitors,a);resetVisitorForm();renderVisitors();};renderVisitors();}

function resetNotificationForm(){ $("notificationForm")?.reset();$("notificationId").value="";$("notificationDate").value=today(); }
function renderNotifications(){
 if(!$("notificationTable"))return;let rows=read(STORE.notifications),q=($("notificationSearch").value||"").toLowerCase(),f=rows.filter(x=>[x.title,x.audience,x.message,x.date].join(" ").toLowerCase().includes(q));
 $("notificationTotal").textContent=rows.length;$("notificationAll").textContent=rows.filter(x=>x.audience==="All").length;$("notificationStudents").textContent=rows.filter(x=>x.audience==="Students").length;$("notificationWardens").textContent=rows.filter(x=>x.audience==="Wardens").length;
 $("notificationTable").innerHTML=f.length?f.map(x=>`<tr><td>${esc(x.title)}</td><td>${esc(x.audience)}</td><td>${esc(x.message)}</td><td>${fmtDate(x.date)}</td><td class="actions"><button onclick="editNotification('${x.id}')">Edit</button><button class="btn danger" onclick="deleteNotification('${x.id}')">Delete</button></td></tr>`).join(""):`<tr><td colspan="5" class="empty">No notifications found.</td></tr>`;
}
function editNotification(id){let x=read(STORE.notifications).find(v=>v.id===id);if(!x)return;$("notificationId").value=x.id;$("notificationTitle").value=x.title;$("notificationAudience").value=x.audience;$("notificationMessage").value=x.message;$("notificationDate").value=x.date;scrollTo(0,0);}
function deleteNotification(id){if(confirm("Delete this notification?")){write(STORE.notifications,read(STORE.notifications).filter(x=>x.id!==id));renderNotifications();}}
function initNotifications(){if(!$("notificationForm"))return;$("notificationDate").value=today();$("notificationForm").onsubmit=e=>{e.preventDefault();let a=read(STORE.notifications),id=$("notificationId").value,x={id:id||uid(),title:$("notificationTitle").value.trim(),audience:$("notificationAudience").value,message:$("notificationMessage").value.trim(),date:$("notificationDate").value};let i=a.findIndex(v=>v.id===id);i>=0?a[i]=x:a.push(x);write(STORE.notifications,a);resetNotificationForm();renderNotifications();};renderNotifications();}

function initSettings(){
 if(!$("settingsForm"))return;let s=read(STORE.settings,{hostelName:"Hostel Management System",academicYear:"2026-27",warden:"",wardenPhone:"",capacity:100,hostelFee:5000,messFee:3000,email:""});
 $("settingHostelName").value=s.hostelName;$("settingAcademicYear").value=s.academicYear;$("settingWarden").value=s.warden;$("settingWardenPhone").value=s.wardenPhone;$("settingCapacity").value=s.capacity;$("settingHostelFee").value=s.hostelFee;$("settingMessFee").value=s.messFee;$("settingEmail").value=s.email;
 $("settingsForm").onsubmit=e=>{e.preventDefault();write(STORE.settings,{hostelName:$("settingHostelName").value.trim(),academicYear:$("settingAcademicYear").value.trim(),warden:$("settingWarden").value.trim(),wardenPhone:$("settingWardenPhone").value.trim(),capacity:Number($("settingCapacity").value||0),hostelFee:Number($("settingHostelFee").value||0),messFee:Number($("settingMessFee").value||0),email:$("settingEmail").value.trim()});alert("Settings saved successfully.");};
 $("passwordForm").onsubmit=e=>{e.preventDefault();if($("newPassword").value!==$("confirmPassword").value){alert("New password and confirmation do not match.");return;}alert("Password updated in demo mode. Connect a secure backend for real authentication.");$("passwordForm").reset();};
}

document.addEventListener("DOMContentLoaded",()=>{seedData();initMess();renderComplaints();initVisitors();initNotifications();initSettings();});
