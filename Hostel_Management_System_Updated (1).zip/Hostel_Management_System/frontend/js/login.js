document
    .getElementById("loginForm")
    .addEventListener("submit", function(event) {

        event.preventDefault();


        const username =
            document.getElementById("username").value.trim();

        const password =
            document.getElementById("password").value;

        const role =
            document.getElementById("role").value;

        const message =
            document.getElementById("loginMessage");


        /*
         * Demo login credentials
         */

        const users = {

            admin: {
                username: "admin",
                password: "admin123"
            },

            warden: {
                username: "warden",
                password: "warden123"
            },

            student: {
                username: "student",
                password: "student123"
            }

        };


        if (!role) {

            message.textContent =
                "Please select your role.";

            return;
        }


        const user = users[role];


        if (
            username === user.username &&
            password === user.password
        ) {

            /*
             * Save login information
             * temporarily in browser.
             */

            sessionStorage.setItem(
                "loggedIn",
                "true"
            );

            sessionStorage.setItem(
                "role",
                role
            );

            sessionStorage.setItem(
                "username",
                username
            );


            message.textContent =
                "Login successful!";


            /*
             * Redirect based on role
             */

            setTimeout(function() {

                if (role === "admin") {

                    window.location.href =
                        "admin/dashboard.html";

                }

                else if (role === "warden") {

                    window.location.href =
                        "warden/dashboard.html";

                }

                else if (role === "student") {

                    window.location.href =
                        "student/dashboard.html";

                }

            }, 500);

        }

        else {

            message.textContent =
                "Invalid username or password.";

        }

    });