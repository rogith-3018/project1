document.addEventListener("DOMContentLoaded", function () {

    // Temporary display values.
    // Later these will come from Spring Boot + MySQL.

    document.getElementById("roomNumber").textContent = "--";
    document.getElementById("feeStatus").textContent = "--";
    document.getElementById("attendancePercentage").textContent = "--";
    document.getElementById("complaintCount").textContent = "--";

    document.getElementById("hostelName").textContent = "--";
    document.getElementById("myRoom").textContent = "--";
    document.getElementById("bedNumber").textContent = "--";

    document.getElementById("totalFee").textContent = "--";
    document.getElementById("paidFee").textContent = "--";
    document.getElementById("pendingFee").textContent = "--";

    document.getElementById("attendanceMessage").textContent =
        "Attendance information will appear after backend connection.";

    document.getElementById("notificationTitle").textContent =
        "No new notification";

    document.getElementById("notificationText").textContent =
        "New hostel announcements will appear here.";

});


function showNotifications() {

    alert("Notification system will be connected later.");
}


function logout() {

    const confirmLogout = confirm(
        "Are you sure you want to logout?"
    );

    if (confirmLogout) {

        // Later JWT/session will be cleared here.

        window.location.href = "../login.html";
    }
}
function editProfile() {
    alert(
        "Profile editing will be connected to the backend later."
    );
}

function showNotifications() {
    alert(
        "Notification system will be connected to the backend later."
    );
}

function logout() {

    const confirmLogout = confirm(
        "Are you sure you want to logout?"
    );

    if (confirmLogout) {
        window.location.href = "../login.html";
    }
}